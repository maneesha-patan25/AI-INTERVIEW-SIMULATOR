// src/routes/sign-out.tsx
import { SignOutButton } from "@clerk/clerk-react";

const SignOutPage = () => {
  return <SignOutButton />;
};

export default SignOutPage;
